# Obtenir l'APK sans rien installer (GitHub fait la compilation)

1. Crée un compte gratuit sur github.com, puis un nouveau dépôt (New repository, privé si tu veux).
2. Dans le dépôt : Add file > Upload files. Glisse tout le contenu de ce dossier (package.json, capacitor.config.json, dossiers www, tools, .github).
   Si le dossier `.github` n'apparaît pas : Add file > Create new file, nomme-le `.github/workflows/apk.yml` et colle le contenu de `apk.yml`.
3. Clique sur « Commit changes ».
4. Onglet **Actions** > « Build APK » : attends 5 à 10 minutes (pastille verte).
5. Ouvre l'exécution terminée > en bas **Artifacts** > `horaires-apk` : tu télécharges un zip contenant `app-debug.apk`.
6. Installe-le sur la télé ou le téléphone (voir LISEZMOI-tv.md, partie 3).

Notes :
- À chaque nouvel envoi de fichiers, GitHub refait un APK. Pour mettre à jour l'appli, désinstalle d'abord l'ancienne (la signature de test change à chaque compilation).
- Si la pastille est rouge, ouvre l'exécution et envoie-moi le message d'erreur.
